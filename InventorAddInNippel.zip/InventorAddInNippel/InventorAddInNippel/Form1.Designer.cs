﻿
//namespace InvAddIn
//{
//    partial class Form1
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            this.SuspendLayout();
//            // 
//            // Form1
//            // 
//            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
//            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
//            this.ClientSize = new System.Drawing.Size(557, 200);
//            this.Name = "Form1";
//            this.Text = "Form1";
//            this.ResumeLayout(false);

//        }

//        #endregion
//    }
//}


namespace InvAddIn
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button37 = new System.Windows.Forms.Button();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button41 = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button42 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button45 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button46 = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button44 = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(8, 78);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(613, 441);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.button37);
            this.tabPage1.Controls.Add(this.groupBox22);
            this.tabPage1.Controls.Add(this.groupBox21);
            this.tabPage1.Controls.Add(this.groupBox20);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(605, 409);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "С шаровым ниппелем под сварку";
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(376, 372);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(100, 28);
            this.button37.TabIndex = 18;
            this.button37.Text = "Отменить";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.checkBox15);
            this.groupBox22.Controls.Add(this.label5);
            this.groupBox22.Location = new System.Drawing.Point(218, 302);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(365, 64);
            this.groupBox22.TabIndex = 5;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Размещение";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Грань 1";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.comboBox16);
            this.groupBox21.Controls.Add(this.checkBox2);
            this.groupBox21.Controls.Add(this.checkBox34);
            this.groupBox21.Controls.Add(this.checkBox1);
            this.groupBox21.Controls.Add(this.label38);
            this.groupBox21.Controls.Add(this.label39);
            this.groupBox21.Controls.Add(this.comboBox1);
            this.groupBox21.Controls.Add(this.label2);
            this.groupBox21.Controls.Add(this.label3);
            this.groupBox21.Controls.Add(this.comboBox10);
            this.groupBox21.Controls.Add(this.label4);
            this.groupBox21.Location = new System.Drawing.Point(218, 157);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(365, 139);
            this.groupBox21.TabIndex = 4;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Параметры";
            // 
            // comboBox16
            // 
            this.comboBox16.Enabled = false;
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Items.AddRange(new object[] {
            "3",
            "5",
            "7",
            "8",
            "10",
            "13",
            "17",
            "23",
            "29",
            "36",
            "2.5",
            "4",
            "6",
            "9",
            "11",
            "14",
            "19",
            "24",
            "32"});
            this.comboBox16.Location = new System.Drawing.Point(194, 99);
            this.comboBox16.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(124, 24);
            this.comboBox16.TabIndex = 27;
            this.comboBox16.TextChanged += new System.EventHandler(this.comboBox16_TextChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 102);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(168, 17);
            this.label38.TabIndex = 25;
            this.label38.Text = "Внутренний диаметр Dv";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(172, 102);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(26, 17);
            this.label39.TabIndex = 26;
            this.label39.Text = "мм";
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "М8х1",
            "М10х1",
            "М12х1.5",
            "М14х1.5",
            "М16х1.5",
            "М18х1.5",
            "М22х1.5",
            "М24х1.5",
            "М26х1.5",
            "М27х2",
            "М30х2",
            "М36х2",
            "М45х2",
            "М52х2",
            "М14х1.5",
            "М16х1.5",
            "М18х1.5",
            "М20х1.5",
            "М22х1.5",
            "М24х1.5",
            "М30х2",
            "М36х2",
            "М42х2",
            "М52х2",
            "М60х2",
            "М72х2",
            "М90х2"});
            this.comboBox1.Location = new System.Drawing.Point(193, 60);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(124, 24);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Резьба";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Наружный диаметр Dn";
            // 
            // comboBox10
            // 
            this.comboBox10.Enabled = false;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "8",
            "10",
            "12",
            "14",
            "15",
            "16",
            "18",
            "20",
            "22",
            "25",
            "28",
            "30",
            "34",
            "35",
            "38",
            "42"});
            this.comboBox10.Location = new System.Drawing.Point(193, 22);
            this.comboBox10.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(124, 24);
            this.comboBox10.TabIndex = 7;
            this.comboBox10.TextChanged += new System.EventHandler(this.comboBox10_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(171, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "мм";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.checkBox3);
            this.groupBox20.Controls.Add(this.checkBox4);
            this.groupBox20.Location = new System.Drawing.Point(7, 7);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(190, 219);
            this.groupBox20.TabIndex = 3;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Тип";
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.Location = new System.Drawing.Point(483, 372);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 28);
            this.button5.TabIndex = 7;
            this.button5.Text = "Добавить";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage2.Controls.Add(this.button41);
            this.tabPage2.Controls.Add(this.groupBox19);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(605, 409);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "С шаровым ниппелем на пайке";
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(376, 372);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(100, 28);
            this.button41.TabIndex = 18;
            this.button41.Text = "Отменить";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.checkBox18);
            this.groupBox19.Controls.Add(this.label9);
            this.groupBox19.Location = new System.Drawing.Point(218, 302);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(365, 64);
            this.groupBox19.TabIndex = 6;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Размещение";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "Грань 1";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.comboBox15);
            this.groupBox6.Controls.Add(this.comboBox11);
            this.groupBox6.Controls.Add(this.comboBox4);
            this.groupBox6.Controls.Add(this.checkBox33);
            this.groupBox6.Controls.Add(this.checkBox16);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.checkBox17);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Location = new System.Drawing.Point(218, 157);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(365, 139);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Параметры";
            // 
            // comboBox15
            // 
            this.comboBox15.Enabled = false;
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Items.AddRange(new object[] {
            "3",
            "5",
            "7",
            "8",
            "10",
            "13",
            "17",
            "23",
            "29",
            "36",
            "2.5",
            "4",
            "6",
            "9",
            "11",
            "14",
            "19",
            "24",
            "32"});
            this.comboBox15.Location = new System.Drawing.Point(194, 99);
            this.comboBox15.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(124, 24);
            this.comboBox15.TabIndex = 23;
            this.comboBox15.TextChanged += new System.EventHandler(this.comboBox15_TextChanged);
            // 
            // comboBox11
            // 
            this.comboBox11.Enabled = false;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "8",
            "10",
            "12",
            "14",
            "15",
            "16",
            "18",
            "20",
            "22",
            "25",
            "28",
            "30",
            "34",
            "35",
            "38",
            "42"});
            this.comboBox11.Location = new System.Drawing.Point(193, 22);
            this.comboBox11.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(124, 24);
            this.comboBox11.TabIndex = 7;
            this.comboBox11.TextChanged += new System.EventHandler(this.comboBox11_TextChanged);
            // 
            // comboBox4
            // 
            this.comboBox4.Enabled = false;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "М8х1",
            "М10х1",
            "М12х1.5",
            "М14х1.5",
            "М16х1.5",
            "М18х1.5",
            "М22х1.5",
            "М24х1.5",
            "М26х1.5",
            "М27х2",
            "М30х2",
            "М36х2",
            "М45х2",
            "М52х2",
            "М14х1.5",
            "М16х1.5",
            "М18х1.5",
            "М20х1.5",
            "М22х1.5",
            "М24х1.5",
            "М30х2",
            "М36х2",
            "М42х2",
            "М52х2"});
            this.comboBox4.Location = new System.Drawing.Point(193, 60);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(124, 24);
            this.comboBox4.TabIndex = 5;
            this.comboBox4.TextChanged += new System.EventHandler(this.comboBox4_TextChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 102);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(168, 17);
            this.label36.TabIndex = 21;
            this.label36.Text = "Внутренний диаметр Dv";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(172, 102);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(26, 17);
            this.label37.TabIndex = 22;
            this.label37.Text = "мм";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "Резьба";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Наружный диаметр Dn";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(171, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "мм";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkBox5);
            this.groupBox5.Controls.Add(this.checkBox6);
            this.groupBox5.Location = new System.Drawing.Point(7, 7);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(190, 219);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Тип";
            // 
            // button8
            // 
            this.button8.Enabled = false;
            this.button8.Location = new System.Drawing.Point(483, 372);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 28);
            this.button8.TabIndex = 5;
            this.button8.Text = "Добавить";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.button42);
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(605, 409);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "С коническим ниппелем 1";
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(376, 372);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(100, 28);
            this.button42.TabIndex = 9;
            this.button42.Text = "Отменить";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.checkBox22);
            this.groupBox8.Controls.Add(this.label15);
            this.groupBox8.Location = new System.Drawing.Point(218, 302);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(365, 64);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Размещение";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 17);
            this.label15.TabIndex = 0;
            this.label15.Text = "Грань 1";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.checkBox21);
            this.groupBox7.Controls.Add(this.checkBox20);
            this.groupBox7.Controls.Add(this.checkBox19);
            this.groupBox7.Controls.Add(this.comboBox2);
            this.groupBox7.Controls.Add(this.comboBox12);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.comboBox3);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Location = new System.Drawing.Point(218, 157);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(365, 139);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Параметры";
            // 
            // comboBox2
            // 
            this.comboBox2.Enabled = false;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "М8х1.25",
            "М10х1",
            "М12х1.5",
            "М14х1.5",
            "М16х1.5",
            "М18х1.5",
            "М22х1.5",
            "М24х1.5",
            "М26х1.5",
            "М27х2",
            "М30х2",
            "М36х2",
            "М45х2",
            "М52х2",
            "М14х1.5",
            "М16х1.5",
            "М18х1.5",
            "М20х1.5",
            "М22х1.5",
            "М24х1.5",
            "М30х2",
            "М36х2",
            "М42х2",
            "М52х2"});
            this.comboBox2.Location = new System.Drawing.Point(193, 60);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(124, 24);
            this.comboBox2.TabIndex = 4;
            this.comboBox2.TextChanged += new System.EventHandler(this.comboBox2_TextChanged);
            // 
            // comboBox12
            // 
            this.comboBox12.Enabled = false;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            "2.5",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "10",
            "11",
            "13",
            "14",
            "17",
            "19",
            "23",
            "24",
            "29",
            "32",
            "36"});
            this.comboBox12.Location = new System.Drawing.Point(194, 99);
            this.comboBox12.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(124, 24);
            this.comboBox12.TabIndex = 7;
            this.comboBox12.TextChanged += new System.EventHandler(this.comboBox12_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 62);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "Резьба";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(158, 17);
            this.label13.TabIndex = 8;
            this.label13.Text = "Наружный диаметр Dn";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(172, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 17);
            this.label10.TabIndex = 5;
            this.label10.Text = "мм";
            // 
            // comboBox3
            // 
            this.comboBox3.Enabled = false;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "6",
            "8",
            "10",
            "12",
            "15",
            "16",
            "18",
            "20",
            "22",
            "25",
            "28",
            "30",
            "35",
            "38",
            "42"});
            this.comboBox3.Location = new System.Drawing.Point(193, 22);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(124, 24);
            this.comboBox3.TabIndex = 7;
            this.comboBox3.TextChanged += new System.EventHandler(this.comboBox3_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(171, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 17);
            this.label14.TabIndex = 9;
            this.label14.Text = "мм";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(168, 17);
            this.label11.TabIndex = 5;
            this.label11.Text = "Внутренний диаметр Dv";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox7);
            this.groupBox3.Controls.Add(this.checkBox8);
            this.groupBox3.Location = new System.Drawing.Point(7, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(190, 219);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Тип";
            // 
            // button7
            // 
            this.button7.Enabled = false;
            this.button7.Location = new System.Drawing.Point(483, 372);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(100, 28);
            this.button7.TabIndex = 4;
            this.button7.Text = "Добавить";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage4.Controls.Add(this.button45);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(605, 409);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "С коническим ниппелем 2";
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(376, 372);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(100, 28);
            this.button45.TabIndex = 10;
            this.button45.Text = "Отменить";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.checkBox26);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Location = new System.Drawing.Point(218, 302);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(365, 64);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Размещение";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 17);
            this.label21.TabIndex = 0;
            this.label21.Text = "Грань 1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox25);
            this.groupBox2.Controls.Add(this.checkBox24);
            this.groupBox2.Controls.Add(this.checkBox23);
            this.groupBox2.Controls.Add(this.comboBox13);
            this.groupBox2.Controls.Add(this.comboBox14);
            this.groupBox2.Controls.Add(this.comboBox5);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Location = new System.Drawing.Point(218, 157);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(365, 139);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Параметры";
            // 
            // comboBox13
            // 
            this.comboBox13.Enabled = false;
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            "4",
            "6",
            "8",
            "10",
            "12",
            "15",
            "20",
            "25",
            "32",
            "40",
            "3",
            "4",
            "5",
            "6",
            "10",
            "12",
            "15",
            "20",
            "25"});
            this.comboBox13.Location = new System.Drawing.Point(194, 99);
            this.comboBox13.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(124, 24);
            this.comboBox13.TabIndex = 7;
            this.comboBox13.TextChanged += new System.EventHandler(this.comboBox13_TextChanged);
            // 
            // comboBox14
            // 
            this.comboBox14.Enabled = false;
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            "6",
            "8",
            "10",
            "12",
            "15",
            "18",
            "22",
            "28",
            "35",
            "42",
            "6",
            "8",
            "10",
            "12",
            "16",
            "20",
            "25",
            "30",
            "38"});
            this.comboBox14.Location = new System.Drawing.Point(193, 22);
            this.comboBox14.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(124, 24);
            this.comboBox14.TabIndex = 8;
            this.comboBox14.TextChanged += new System.EventHandler(this.comboBox14_TextChanged);
            // 
            // comboBox5
            // 
            this.comboBox5.Enabled = false;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(193, 60);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(124, 24);
            this.comboBox5.TabIndex = 0;
            this.comboBox5.TextChanged += new System.EventHandler(this.comboBox5_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 62);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 17);
            this.label20.TabIndex = 0;
            this.label20.Text = "Резьба";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(171, 25);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 17);
            this.label16.TabIndex = 9;
            this.label16.Text = "мм";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(172, 102);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 17);
            this.label18.TabIndex = 5;
            this.label18.Text = "мм";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(158, 17);
            this.label17.TabIndex = 8;
            this.label17.Text = "Наружный диаметр Dn";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 102);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(168, 17);
            this.label19.TabIndex = 5;
            this.label19.Text = "Внутренний диаметр Dv";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox9);
            this.groupBox1.Controls.Add(this.checkBox10);
            this.groupBox1.Location = new System.Drawing.Point(7, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(190, 219);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Тип";
            // 
            // button10
            // 
            this.button10.Enabled = false;
            this.button10.Location = new System.Drawing.Point(483, 372);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(100, 28);
            this.button10.TabIndex = 6;
            this.button10.Text = "Добавить";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage5.Controls.Add(this.button46);
            this.tabPage5.Controls.Add(this.groupBox11);
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.button11);
            this.tabPage5.Controls.Add(this.pictureBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 28);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(605, 409);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "По наружному конусу 1";
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(376, 335);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(100, 28);
            this.button46.TabIndex = 11;
            this.button46.Text = "Отменить";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.checkBox29);
            this.groupBox11.Controls.Add(this.label25);
            this.groupBox11.Location = new System.Drawing.Point(218, 263);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(365, 67);
            this.groupBox11.TabIndex = 10;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Размещение";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 27);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 17);
            this.label25.TabIndex = 0;
            this.label25.Text = "Грань 1";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.checkBox28);
            this.groupBox10.Controls.Add(this.checkBox27);
            this.groupBox10.Controls.Add(this.comboBox6);
            this.groupBox10.Controls.Add(this.comboBox7);
            this.groupBox10.Controls.Add(this.label22);
            this.groupBox10.Controls.Add(this.label23);
            this.groupBox10.Controls.Add(this.label24);
            this.groupBox10.Location = new System.Drawing.Point(218, 157);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(365, 100);
            this.groupBox10.TabIndex = 9;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Параметры";
            // 
            // comboBox6
            // 
            this.comboBox6.Enabled = false;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "3",
            "4",
            "6",
            "8",
            "10",
            "12",
            "14",
            "16",
            "18",
            "20",
            "22",
            "25",
            "28",
            "30",
            "32",
            "34",
            "36",
            "38"});
            this.comboBox6.Location = new System.Drawing.Point(193, 22);
            this.comboBox6.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(124, 24);
            this.comboBox6.TabIndex = 2;
            this.comboBox6.TextChanged += new System.EventHandler(this.comboBox6_TextChanged);
            // 
            // comboBox7
            // 
            this.comboBox7.Enabled = false;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(193, 60);
            this.comboBox7.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(124, 24);
            this.comboBox7.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(171, 25);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 17);
            this.label22.TabIndex = 5;
            this.label22.Text = "мм";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 25);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(158, 17);
            this.label23.TabIndex = 5;
            this.label23.Text = "Наружный диаметр Dn";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 63);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 17);
            this.label24.TabIndex = 0;
            this.label24.Text = "Резьба";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.checkBox11);
            this.groupBox9.Controls.Add(this.checkBox12);
            this.groupBox9.Location = new System.Drawing.Point(7, 7);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(190, 219);
            this.groupBox9.TabIndex = 7;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Тип";
            // 
            // button11
            // 
            this.button11.Enabled = false;
            this.button11.Location = new System.Drawing.Point(483, 335);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(100, 28);
            this.button11.TabIndex = 3;
            this.button11.Text = "Добавить";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage6.Controls.Add(this.button44);
            this.tabPage6.Controls.Add(this.groupBox14);
            this.tabPage6.Controls.Add(this.groupBox13);
            this.tabPage6.Controls.Add(this.groupBox12);
            this.tabPage6.Controls.Add(this.button12);
            this.tabPage6.Controls.Add(this.pictureBox6);
            this.tabPage6.Location = new System.Drawing.Point(4, 28);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(605, 409);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "По наружному конусу 2";
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(376, 335);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(100, 28);
            this.button44.TabIndex = 12;
            this.button44.Text = "Отменить";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.checkBox32);
            this.groupBox14.Controls.Add(this.label29);
            this.groupBox14.Location = new System.Drawing.Point(218, 263);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(365, 67);
            this.groupBox14.TabIndex = 11;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Размещение";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 27);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 17);
            this.label29.TabIndex = 0;
            this.label29.Text = "Грань 1";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.checkBox31);
            this.groupBox13.Controls.Add(this.checkBox30);
            this.groupBox13.Controls.Add(this.comboBox9);
            this.groupBox13.Controls.Add(this.label28);
            this.groupBox13.Controls.Add(this.comboBox8);
            this.groupBox13.Controls.Add(this.label27);
            this.groupBox13.Controls.Add(this.label26);
            this.groupBox13.Location = new System.Drawing.Point(218, 157);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(365, 100);
            this.groupBox13.TabIndex = 10;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Параметры";
            // 
            // comboBox9
            // 
            this.comboBox9.Enabled = false;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(193, 60);
            this.comboBox9.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(124, 24);
            this.comboBox9.TabIndex = 4;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 63);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 17);
            this.label28.TabIndex = 0;
            this.label28.Text = "Резьба";
            // 
            // comboBox8
            // 
            this.comboBox8.Enabled = false;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "3",
            "4",
            "6",
            "8",
            "10",
            "12",
            "14",
            "16",
            "18",
            "20",
            "22",
            "25",
            "28",
            "30",
            "32",
            "34",
            "36",
            "38"});
            this.comboBox8.Location = new System.Drawing.Point(193, 22);
            this.comboBox8.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(124, 24);
            this.comboBox8.TabIndex = 4;
            this.comboBox8.TextChanged += new System.EventHandler(this.comboBox8_TextChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 25);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(158, 17);
            this.label27.TabIndex = 5;
            this.label27.Text = "Наружный диаметр Dn";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(171, 25);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 17);
            this.label26.TabIndex = 5;
            this.label26.Text = "мм";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.checkBox13);
            this.groupBox12.Controls.Add(this.checkBox14);
            this.groupBox12.Location = new System.Drawing.Point(7, 7);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(190, 219);
            this.groupBox12.TabIndex = 8;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Тип";
            // 
            // button12
            // 
            this.button12.Enabled = false;
            this.button12.Location = new System.Drawing.Point(483, 335);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(100, 28);
            this.button12.TabIndex = 3;
            this.button12.Text = "Добавить";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(415, 123);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(81, 23);
            this.button24.TabIndex = 6;
            this.button24.Text = "Грань кас";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(415, 19);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(61, 24);
            this.button22.TabIndex = 5;
            this.button22.Text = "Резьба";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(415, 51);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(63, 24);
            this.button16.TabIndex = 4;
            this.button16.Text = "Dn";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(334, 123);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(71, 23);
            this.button26.TabIndex = 6;
            this.button26.Text = "Грань кас";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(334, 51);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(62, 24);
            this.button15.TabIndex = 4;
            this.button15.Text = "Dn";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(334, 19);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(62, 24);
            this.button21.TabIndex = 5;
            this.button21.Text = "Резьба";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(241, 148);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(62, 27);
            this.button28.TabIndex = 9;
            this.button28.Text = "Грань вставка";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(241, 19);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(62, 24);
            this.button14.TabIndex = 7;
            this.button14.Text = "Dy";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(241, 84);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(62, 24);
            this.button20.TabIndex = 8;
            this.button20.Text = "Резьба";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(241, 51);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(62, 24);
            this.button30.TabIndex = 11;
            this.button30.Text = "Dn";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(143, 151);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(83, 24);
            this.button32.TabIndex = 9;
            this.button32.Text = "Грань вставка";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(143, 56);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(62, 24);
            this.button31.TabIndex = 8;
            this.button31.Text = "Dn";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(142, 18);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(62, 25);
            this.button13.TabIndex = 6;
            this.button13.Text = "Dy";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(142, 86);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(62, 24);
            this.button19.TabIndex = 7;
            this.button19.Text = "Резьба";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(11, 129);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(55, 24);
            this.button36.TabIndex = 16;
            this.button36.Text = "Грань вставка";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(4, 65);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(62, 24);
            this.button6.TabIndex = 10;
            this.button6.Text = "Грань";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(4, 19);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(62, 25);
            this.button17.TabIndex = 13;
            this.button17.Text = "Резьба";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(72, 126);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(61, 24);
            this.button34.TabIndex = 8;
            this.button34.Text = "Грань корпуса";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(74, 64);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(62, 24);
            this.button9.TabIndex = 6;
            this.button9.Text = "Грань";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(72, 19);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(62, 24);
            this.button18.TabIndex = 7;
            this.button18.Text = "Резьба";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.button24);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.button16);
            this.panel1.Controls.Add(this.button22);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button28);
            this.panel1.Controls.Add(this.button21);
            this.panel1.Controls.Add(this.button32);
            this.panel1.Controls.Add(this.button34);
            this.panel1.Controls.Add(this.button20);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.button36);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button30);
            this.panel1.Controls.Add(this.button19);
            this.panel1.Controls.Add(this.button31);
            this.panel1.Controls.Add(this.button17);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Location = new System.Drawing.Point(110, 524);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(541, 201);
            this.panel1.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pictureBox7);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(605, 66);
            this.panel2.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(504, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Ниппельное соединение. ГОСТ 23355-78 Шаровой ниппель. Исполнение 1";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Menu;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(12, 78);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(604, 357);
            this.panel3.TabIndex = 18;
            this.panel3.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Window;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label35);
            this.panel4.Controls.Add(this.pictureBox13);
            this.panel4.Controls.Add(this.label34);
            this.panel4.Controls.Add(this.pictureBox12);
            this.panel4.Controls.Add(this.label33);
            this.panel4.Controls.Add(this.pictureBox11);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.pictureBox10);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.pictureBox9);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.pictureBox8);
            this.panel4.Location = new System.Drawing.Point(13, 25);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(574, 310);
            this.panel4.TabIndex = 0;
            this.panel4.Visible = false;
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(427, 214);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(100, 55);
            this.label35.TabIndex = 11;
            this.label35.Text = "Ниппель ГОСТ 13956-74. Исполнение 2";
            this.label35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(242, 216);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(100, 55);
            this.label34.TabIndex = 9;
            this.label34.Text = "Ниппель ГОСТ 13956-74. Исполнение 1";
            this.label34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(38, 216);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(100, 68);
            this.label33.TabIndex = 7;
            this.label33.Text = "Конический ниппель ГОСТ 28016-89. Исполнение 2";
            this.label33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(427, 68);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 68);
            this.label32.TabIndex = 5;
            this.label32.Text = "Конический ниппель ГОСТ 28016-89. Исполнение 1";
            this.label32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(239, 68);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(100, 68);
            this.label31.TabIndex = 3;
            this.label31.Text = "Шаровой ниппель ГОСТ 23353-78. Исполнение 2";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(35, 68);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(103, 68);
            this.label30.TabIndex = 1;
            this.label30.Text = "Шаровой ниппель ГОСТ 23353-78. Исполнение 1";
            this.label30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::InvAddIn.Properties.Resources.image_231;
            this.pictureBox7.Location = new System.Drawing.Point(570, -1);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(34, 66);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 18;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // checkBox15
            // 
            this.checkBox15.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox15.AutoSize = true;
            this.checkBox15.Enabled = false;
            this.checkBox15.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox15.Location = new System.Drawing.Point(71, 21);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(35, 34);
            this.checkBox15.TabIndex = 18;
            this.checkBox15.UseVisualStyleBackColor = true;
            this.checkBox15.CheckedChanged += new System.EventHandler(this.checkBox15_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox2.Location = new System.Drawing.Point(324, 17);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(35, 34);
            this.checkBox2.TabIndex = 18;
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox34
            // 
            this.checkBox34.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox34.AutoSize = true;
            this.checkBox34.Enabled = false;
            this.checkBox34.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox34.Location = new System.Drawing.Point(324, 95);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(35, 34);
            this.checkBox34.TabIndex = 28;
            this.checkBox34.UseVisualStyleBackColor = true;
            this.checkBox34.CheckedChanged += new System.EventHandler(this.checkBox34_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox1.Location = new System.Drawing.Point(324, 56);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(35, 34);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox3.AutoSize = true;
            this.checkBox3.Image = global::InvAddIn.Properties.Resources.tr_ch8_1;
            this.checkBox3.Location = new System.Drawing.Point(28, 117);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(135, 86);
            this.checkBox3.TabIndex = 1;
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.Click += new System.EventHandler(this.checkBox3_Click);
            // 
            // checkBox4
            // 
            this.checkBox4.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox4.AutoSize = true;
            this.checkBox4.Image = global::InvAddIn.Properties.Resources.sh_ch2;
            this.checkBox4.Location = new System.Drawing.Point(28, 21);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(135, 86);
            this.checkBox4.TabIndex = 2;
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.Click += new System.EventHandler(this.checkBox4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::InvAddIn.Properties.Resources.sh1_tr;
            this.pictureBox1.Location = new System.Drawing.Point(218, 24);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(290, 126);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // checkBox18
            // 
            this.checkBox18.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox18.AutoSize = true;
            this.checkBox18.Enabled = false;
            this.checkBox18.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox18.Location = new System.Drawing.Point(71, 21);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(35, 34);
            this.checkBox18.TabIndex = 21;
            this.checkBox18.UseVisualStyleBackColor = true;
            this.checkBox18.CheckedChanged += new System.EventHandler(this.checkBox18_CheckedChanged);
            // 
            // checkBox33
            // 
            this.checkBox33.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox33.AutoSize = true;
            this.checkBox33.Enabled = false;
            this.checkBox33.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox33.Location = new System.Drawing.Point(324, 95);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(35, 34);
            this.checkBox33.TabIndex = 24;
            this.checkBox33.UseVisualStyleBackColor = true;
            this.checkBox33.CheckedChanged += new System.EventHandler(this.checkBox33_CheckedChanged);
            // 
            // checkBox16
            // 
            this.checkBox16.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox16.AutoSize = true;
            this.checkBox16.Enabled = false;
            this.checkBox16.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox16.Location = new System.Drawing.Point(324, 17);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(35, 34);
            this.checkBox16.TabIndex = 19;
            this.checkBox16.UseVisualStyleBackColor = true;
            this.checkBox16.CheckedChanged += new System.EventHandler(this.checkBox16_CheckedChanged);
            // 
            // checkBox17
            // 
            this.checkBox17.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox17.AutoSize = true;
            this.checkBox17.Enabled = false;
            this.checkBox17.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox17.Location = new System.Drawing.Point(324, 56);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(35, 34);
            this.checkBox17.TabIndex = 20;
            this.checkBox17.UseVisualStyleBackColor = true;
            this.checkBox17.CheckedChanged += new System.EventHandler(this.checkBox17_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox5.AutoSize = true;
            this.checkBox5.Image = global::InvAddIn.Properties.Resources.tr_ch8_1;
            this.checkBox5.Location = new System.Drawing.Point(28, 117);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(135, 86);
            this.checkBox5.TabIndex = 1;
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.Click += new System.EventHandler(this.checkBox5_Click);
            // 
            // checkBox6
            // 
            this.checkBox6.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox6.AutoSize = true;
            this.checkBox6.Image = global::InvAddIn.Properties.Resources.sh_ch2;
            this.checkBox6.Location = new System.Drawing.Point(28, 21);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(135, 86);
            this.checkBox6.TabIndex = 2;
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.Click += new System.EventHandler(this.checkBox6_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::InvAddIn.Properties.Resources.sh2_tr;
            this.pictureBox2.Location = new System.Drawing.Point(218, 24);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(206, 126);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // checkBox22
            // 
            this.checkBox22.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox22.AutoSize = true;
            this.checkBox22.Enabled = false;
            this.checkBox22.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox22.Location = new System.Drawing.Point(71, 21);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(35, 34);
            this.checkBox22.TabIndex = 25;
            this.checkBox22.UseVisualStyleBackColor = true;
            this.checkBox22.CheckedChanged += new System.EventHandler(this.checkBox22_CheckedChanged);
            // 
            // checkBox21
            // 
            this.checkBox21.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox21.AutoSize = true;
            this.checkBox21.Enabled = false;
            this.checkBox21.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox21.Location = new System.Drawing.Point(324, 56);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(35, 34);
            this.checkBox21.TabIndex = 24;
            this.checkBox21.UseVisualStyleBackColor = true;
            this.checkBox21.CheckedChanged += new System.EventHandler(this.checkBox21_CheckedChanged);
            // 
            // checkBox20
            // 
            this.checkBox20.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox20.AutoSize = true;
            this.checkBox20.Enabled = false;
            this.checkBox20.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox20.Location = new System.Drawing.Point(324, 17);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(35, 34);
            this.checkBox20.TabIndex = 24;
            this.checkBox20.UseVisualStyleBackColor = true;
            this.checkBox20.CheckedChanged += new System.EventHandler(this.checkBox20_CheckedChanged);
            // 
            // checkBox19
            // 
            this.checkBox19.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox19.AutoSize = true;
            this.checkBox19.Enabled = false;
            this.checkBox19.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox19.Location = new System.Drawing.Point(324, 95);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(35, 34);
            this.checkBox19.TabIndex = 24;
            this.checkBox19.UseVisualStyleBackColor = true;
            this.checkBox19.CheckedChanged += new System.EventHandler(this.checkBox19_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox7.AutoSize = true;
            this.checkBox7.Image = global::InvAddIn.Properties.Resources.tr_ch8_1;
            this.checkBox7.Location = new System.Drawing.Point(28, 117);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(135, 86);
            this.checkBox7.TabIndex = 1;
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.Click += new System.EventHandler(this.checkBox7_Click);
            // 
            // checkBox8
            // 
            this.checkBox8.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox8.AutoSize = true;
            this.checkBox8.Image = global::InvAddIn.Properties.Resources.sh_ch2;
            this.checkBox8.Location = new System.Drawing.Point(28, 21);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(135, 86);
            this.checkBox8.TabIndex = 2;
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.Click += new System.EventHandler(this.checkBox8_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::InvAddIn.Properties.Resources.Н_КН12;
            this.pictureBox3.Location = new System.Drawing.Point(218, 24);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(233, 126);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // checkBox26
            // 
            this.checkBox26.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox26.AutoSize = true;
            this.checkBox26.Enabled = false;
            this.checkBox26.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox26.Location = new System.Drawing.Point(71, 21);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(35, 34);
            this.checkBox26.TabIndex = 25;
            this.checkBox26.UseVisualStyleBackColor = true;
            this.checkBox26.CheckedChanged += new System.EventHandler(this.checkBox26_CheckedChanged);
            // 
            // checkBox25
            // 
            this.checkBox25.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox25.AutoSize = true;
            this.checkBox25.Enabled = false;
            this.checkBox25.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox25.Location = new System.Drawing.Point(324, 56);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(35, 34);
            this.checkBox25.TabIndex = 25;
            this.checkBox25.UseVisualStyleBackColor = true;
            this.checkBox25.CheckedChanged += new System.EventHandler(this.checkBox25_CheckedChanged);
            // 
            // checkBox24
            // 
            this.checkBox24.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox24.AutoSize = true;
            this.checkBox24.Enabled = false;
            this.checkBox24.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox24.Location = new System.Drawing.Point(324, 17);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(35, 34);
            this.checkBox24.TabIndex = 25;
            this.checkBox24.UseVisualStyleBackColor = true;
            this.checkBox24.CheckedChanged += new System.EventHandler(this.checkBox24_CheckedChanged);
            // 
            // checkBox23
            // 
            this.checkBox23.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox23.AutoSize = true;
            this.checkBox23.Enabled = false;
            this.checkBox23.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox23.Location = new System.Drawing.Point(324, 95);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(35, 34);
            this.checkBox23.TabIndex = 25;
            this.checkBox23.UseVisualStyleBackColor = true;
            this.checkBox23.CheckedChanged += new System.EventHandler(this.checkBox23_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox9.AutoSize = true;
            this.checkBox9.Image = global::InvAddIn.Properties.Resources.tr_ch8_1;
            this.checkBox9.Location = new System.Drawing.Point(28, 117);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(135, 86);
            this.checkBox9.TabIndex = 1;
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.Click += new System.EventHandler(this.checkBox9_Click);
            // 
            // checkBox10
            // 
            this.checkBox10.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox10.AutoSize = true;
            this.checkBox10.Image = global::InvAddIn.Properties.Resources.sh_ch2;
            this.checkBox10.Location = new System.Drawing.Point(28, 21);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(135, 86);
            this.checkBox10.TabIndex = 2;
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.Click += new System.EventHandler(this.checkBox10_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::InvAddIn.Properties.Resources.Н_КН2;
            this.pictureBox4.Location = new System.Drawing.Point(218, 24);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(236, 126);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // checkBox29
            // 
            this.checkBox29.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox29.AutoSize = true;
            this.checkBox29.Enabled = false;
            this.checkBox29.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox29.Location = new System.Drawing.Point(71, 21);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(35, 34);
            this.checkBox29.TabIndex = 26;
            this.checkBox29.UseVisualStyleBackColor = true;
            this.checkBox29.CheckedChanged += new System.EventHandler(this.checkBox29_CheckedChanged);
            // 
            // checkBox28
            // 
            this.checkBox28.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox28.AutoSize = true;
            this.checkBox28.Enabled = false;
            this.checkBox28.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox28.Location = new System.Drawing.Point(324, 17);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(35, 34);
            this.checkBox28.TabIndex = 26;
            this.checkBox28.UseVisualStyleBackColor = true;
            this.checkBox28.CheckedChanged += new System.EventHandler(this.checkBox28_CheckedChanged);
            // 
            // checkBox27
            // 
            this.checkBox27.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox27.AutoSize = true;
            this.checkBox27.Enabled = false;
            this.checkBox27.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox27.Location = new System.Drawing.Point(324, 56);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(35, 34);
            this.checkBox27.TabIndex = 26;
            this.checkBox27.UseVisualStyleBackColor = true;
            this.checkBox27.CheckedChanged += new System.EventHandler(this.checkBox27_CheckedChanged);
            // 
            // checkBox11
            // 
            this.checkBox11.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox11.AutoSize = true;
            this.checkBox11.Image = global::InvAddIn.Properties.Resources.tr_ch8_1;
            this.checkBox11.Location = new System.Drawing.Point(28, 117);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(135, 86);
            this.checkBox11.TabIndex = 1;
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.Click += new System.EventHandler(this.checkBox11_Click);
            // 
            // checkBox12
            // 
            this.checkBox12.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox12.AutoSize = true;
            this.checkBox12.Image = global::InvAddIn.Properties.Resources.sh_ch2;
            this.checkBox12.Location = new System.Drawing.Point(28, 21);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(135, 86);
            this.checkBox12.TabIndex = 2;
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.Click += new System.EventHandler(this.checkBox12_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::InvAddIn.Properties.Resources.Н_ПК1;
            this.pictureBox5.Location = new System.Drawing.Point(218, 24);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(207, 126);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // checkBox32
            // 
            this.checkBox32.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox32.AutoSize = true;
            this.checkBox32.Enabled = false;
            this.checkBox32.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox32.Location = new System.Drawing.Point(71, 21);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(35, 34);
            this.checkBox32.TabIndex = 27;
            this.checkBox32.UseVisualStyleBackColor = true;
            this.checkBox32.CheckedChanged += new System.EventHandler(this.checkBox32_CheckedChanged);
            // 
            // checkBox31
            // 
            this.checkBox31.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox31.AutoSize = true;
            this.checkBox31.Enabled = false;
            this.checkBox31.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox31.Location = new System.Drawing.Point(324, 17);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(35, 34);
            this.checkBox31.TabIndex = 27;
            this.checkBox31.UseVisualStyleBackColor = true;
            this.checkBox31.CheckedChanged += new System.EventHandler(this.checkBox31_CheckedChanged);
            // 
            // checkBox30
            // 
            this.checkBox30.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox30.AutoSize = true;
            this.checkBox30.Enabled = false;
            this.checkBox30.Image = global::InvAddIn.Properties.Resources.image_23;
            this.checkBox30.Location = new System.Drawing.Point(324, 56);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(35, 34);
            this.checkBox30.TabIndex = 27;
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox13.AutoSize = true;
            this.checkBox13.Image = global::InvAddIn.Properties.Resources.tr_ch8_1;
            this.checkBox13.Location = new System.Drawing.Point(28, 117);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(135, 86);
            this.checkBox13.TabIndex = 1;
            this.checkBox13.UseVisualStyleBackColor = true;
            this.checkBox13.Click += new System.EventHandler(this.checkBox13_Click);
            // 
            // checkBox14
            // 
            this.checkBox14.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox14.AutoSize = true;
            this.checkBox14.Image = global::InvAddIn.Properties.Resources.sh_ch2;
            this.checkBox14.Location = new System.Drawing.Point(28, 21);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(135, 86);
            this.checkBox14.TabIndex = 2;
            this.checkBox14.UseVisualStyleBackColor = true;
            this.checkBox14.Click += new System.EventHandler(this.checkBox14_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::InvAddIn.Properties.Resources.Н_ПК2;
            this.pictureBox6.Location = new System.Drawing.Point(218, 24);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(193, 126);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 9;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::InvAddIn.Properties.Resources.Н_ПК1;
            this.pictureBox13.Location = new System.Drawing.Point(427, 159);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(100, 50);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 10;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.label35_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::InvAddIn.Properties.Resources.Н_ПК1;
            this.pictureBox12.Location = new System.Drawing.Point(242, 161);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(100, 50);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 8;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.label34_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::InvAddIn.Properties.Resources.Н_КН22;
            this.pictureBox11.Location = new System.Drawing.Point(38, 161);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(100, 50);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 6;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.label33_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::InvAddIn.Properties.Resources.Н_КН1;
            this.pictureBox10.Location = new System.Drawing.Point(427, 13);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(100, 50);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 4;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.label32_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::InvAddIn.Properties.Resources.sh2_sh;
            this.pictureBox9.Location = new System.Drawing.Point(239, 13);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(100, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 2;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.label31_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::InvAddIn.Properties.Resources.sh1_sh;
            this.pictureBox8.Location = new System.Drawing.Point(38, 13);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(100, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.label30_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 521);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel3);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Генератор компонентов ниппельного соединения";
            this.TopMost = true;
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
    }
}

